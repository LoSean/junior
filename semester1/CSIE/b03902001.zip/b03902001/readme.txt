1. Execution Environment: CSIE Workstation
2. Computer Language: C++
3. Compile:
	$make
4. Execution:
	$make run 
	(get parameters from stdin, 
	and the order follows: S -> X -> maturity ->
	annual volatility -> annual interest rate ->
	number of period)
5. Delete the Execution File:
	$make clean
